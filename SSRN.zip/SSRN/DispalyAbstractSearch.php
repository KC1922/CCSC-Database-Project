<?php
  include_once 'includes/dbh-inc.php';
?>

<!DOCTYPE html>
<html>
  <head>
    <title>
      Search eLibrary :: SSRN
    </title>

    <link rel="stylesheet" href="styles/general.css">
    <link rel="stylesheet" href="styles/header.css">
    <link rel="stylesheet" href="styles/footer.css">
  </head>

  <body>
    <?php
      $sql = "SELECT * FROM `user`;";
      $result = mysqli_query($conn, $sql);

      // $resultCheck = mysqli_num_rows($result);

      // if ($resultCheck > 0) {
      //   while ($row = mysqli_fetch_assoc($result)) {
      //     echo $row['fname'];
      //   }
      // }
    ?>

    <header class="header">
      <div class="left-container">
        <a href="">
          <img class="ssrn-logo" src="images/SSRNlogo.png">
        </a>
      </div>

      <div class="right-container">
        <div class="product-and-services">
          Product & Services
        </div>

        <div class="subscribe">
          <a href="">
            Subscribe
          </a>
        </div>

        <div class="submit-a-paper">
          <a href="">
            Submit a paper
          </a>
        </div>

        <div class="browse">
          <a href="">
            Browse
          </a>
        </div>

        <div class="rankings">
          Rankings
        </div>

        <div class="contact">
          <a href="">
            Contact
          </a>
        </div>

        <div class="search-icon-div">
          <a href="">
            <img class="search-icon" src="icons/search.webp">
          </a>
        </div>

        <div class="shopping-cart-icon-div">
          <a href="">
            <img class="shopping-cart-icon" src="icons/shopping-cart.png">
          </a>
        </div>

        <div class="create-account-div">
          <a href="">
            <button class="create-account">
              Create account
            </button>
          </a>
        </div>

        <div class="sign-in-div">
          <a href="">
            <button class="sign-in">
              Sign in
            </button>
          </a>
        </div>
      </div>
    </header>

    <div class="content">
      content
    </div>

    <div class="footer">
      <div class="row1-1">
        <div class="column1-1">
          <div class="row2-1">
            <button class="submit-a-paper-button">
              Submit a Paper &#8250;
            </button>
          </div>
          
          <a href="">
            <div class="row2-2">
              Section 508 Text Only Pages
            </div>
          </a>
        </div>

        <div class="column1-2">
          <div>
            SSRN Quick Links
          </div>

          <a href="">
            <div>
              SSRN Solutions
            </div>
          </a>

          <a href="">
            <div>
              Research Paper Series
            </div>
          </a>

          <a href="">
            <div>
              Conference Papers
            </div>
          </a>

          <a href="">
            <div>
              Partners in Publishing
            </div>
          </a>

          <a href="">
            <div>
              Jobs & Announcements
            </div>
          </a>

          <a href="">
            <div>
              Newsletter Sign Up
            </div>
          </a>
        </div>

        <div class="column1-3">
          <div>
            SSRN Rankings
          </div>

          <a href="">
            <div>
              Top Papers
            </div>
          </a>

          <a href="">
            <div>
              Top Authors
            </div>
          </a>

          <a href="">
            <div>
              Top Organizations
            </div>
          </a>
        </div>

        <div class="column1-4">
          <div>
            About SSRN
          </div>

          <a href="">
            <div>
              SSRN Objectives
            </div>
          </a>

          <a href="">
            <div>
              Network Directors
            </div>
          </a>

          <a href="">
            <div>
              Presidential Letter
            </div>
          </a>

          <a href="">
            <div>
              Announcements
            </div>
          </a>

          <a href="">
            <div>
              Contact us
            </div>
          </a>

          <a href="">
            <div>
              FAQs
            </div>
          </a>
        </div>
      </div>

      <div class="row1-2">
        test
      </div>

      <div class="row1-3">
        <button class="test">
          test
        </button>
      </div>
    </div>
  </body>
</html>
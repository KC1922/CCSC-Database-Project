<!DOCTYPE html>
<html>
  <head>
    <title>
      SSRN Sign in Join
    </title>

    <link rel="stylesheet" href="styles/general.css">
    <link rel="stylesheet" href="styles/header.css">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/create-signin.css">
  <body>
    <header class="header">
      <div class="left-container">
        <a href="">
          <img class="ssrn-logo" src="images/SSRNlogo.png">
        </a>
      </div>

      <div class="right-container">
        <div class="product-and-services">
          Product & Services
        </div>

        <div class="subscribe">
          <a href="">
            Subscribe
          </a>
        </div>

        <div class="submit-a-paper">
          <a href="">
            Submit a paper
          </a>
        </div>

        <div class="browse">
          <a href="">
            Browse
          </a>
        </div>

        <div class="rankings">
          Rankings
        </div>

        <div class="contact">
          <a href="">
            Contact
          </a>
        </div>

        <div class="search-icon-div">
          <a href="">
            <img class="search-icon" src="icons/search.webp">
          </a>
        </div>

        <div class="shopping-cart-icon-div">
          <a href="">
            <img class="shopping-cart-icon" src="icons/shopping-cart.png">
          </a>
        </div>

        <div class="create-account-div">
          <a href="">
            <button class="create-account">
              Create account
            </button>
          </a>
        </div>

        <div class="sign-in-div">
          <a href="">
            <button class="sign-in">
              Sign in
            </button>
          </a>
        </div>
      </div>
    </header>

    <div class="create-signin-container">
      <div class="signin-container">
        <div class="signin-div">
          Sign in
        </div>

        <div class="email-address-div">
          <input class="email-address" type="text" name="email" placeholder="Email Address">
        </div>

        <div class="password-div">
          <input type="text" name="pwd" placeholder="Password">
        </div>

        <div class="remember-forgot-div">
          <div class="remember-div">
            <input type="checkbox">
            Remember me
          </div>

          <div class="forgot-password-div">
            Forgot password?
          </div>
        </div>

        <div class="signin-div-button">
          <button class="signin-button">
            Sign in
          </button>
        </div>
      </div>

      <div class="create-container">
        <div class="create-div">
          Create an Account
        </div>
  
        <div class="membership-div">
          SSRN Membership is always free.
        </div>
  
        <div class="share-and-revise-div">
          By creating an account, you can easily share and revise your research; view and download the latest research in your field; and interact with thousands of scholars worldwide.
        </div>
  
        <div class="email-address-div">
          <form action="includes/signup-inc.php" method="POST">
            <input class="email-address" type="text" name="email" placeholder="Email Address">
            <button class="join-button" type="submit" name="submit">
              Join SSRN
            </button>
          </form>
        </div>
  
        <div class="join-div">
          
        </div>
  
        <div>
          Privacy Policy
        </div>
      </div>
    </div>
  </body>
</html>
<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "ssrn_database";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);